package com.dailycodebuffer.departmentservice.controller;

import com.dailycodebuffer.departmentservice.client.EmployeeClient;
import com.dailycodebuffer.departmentservice.model.Department;
import com.dailycodebuffer.departmentservice.repository.DepartmentRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Logger;

@RestController
@RequiredArgsConstructor
@RequestMapping("/department")
public class DepartmentController {

//   private static final Logger LOGGER = LoggerFactory.getLogger(DepartmentController.class);
   private final DepartmentRepository departmentRepository;

   private final EmployeeClient employeeClient;


   @PostMapping
   public Department addDepartment(@RequestBody Department department){
//       LOGGER.info("Department added");
       return departmentRepository.addDepartment(department);
   }

   @GetMapping
    public List<Department> getAllDepartments(){
//       LOGGER.info("Getting all departments");
        return departmentRepository.getAllDepartments();
    }

    @GetMapping("/{id}")
    public Department getDepartmentById(@PathVariable Long id){
//       LOGGER.info("Getting department by id: {}");
        return departmentRepository.getDepartmentById(id);
    }


    @GetMapping("/with-employees")
    public List<Department> findDepartmentsWithEmployees(){
        List<Department> departments =
                departmentRepository.getAllDepartments();

        departments.forEach(department -> {
            department.setEmployees(employeeClient.getEmployeesByDepartmentId(department.getId()));
        });

        return departments;
    }




}
