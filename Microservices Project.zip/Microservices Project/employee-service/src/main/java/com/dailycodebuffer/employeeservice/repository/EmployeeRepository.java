package com.dailycodebuffer.employeeservice.repository;

import com.dailycodebuffer.employeeservice.model.Employee;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class EmployeeRepository {

    private List<Employee> employees = new ArrayList<>();

    public Employee addEmployee(Employee employee){
        employees.add(employee);
        return employee;
    }

    public Employee getEmployeeById(Long id){
        return employees
                .stream()
                .filter(employee -> employee.id().equals(id))
                .findFirst().orElse(null);
    }

    public List<Employee> getAllEmployees(){
        return employees;
    }

    public List<Employee> getEmployeesByDepartmentId(Long departmentId){
        return employees
                .stream()
                .filter(employee -> employee.departmentId().equals(departmentId))
                .toList();
    }
}
