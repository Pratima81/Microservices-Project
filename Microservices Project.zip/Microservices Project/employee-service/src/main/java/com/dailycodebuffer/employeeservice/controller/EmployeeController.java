package com.dailycodebuffer.employeeservice.controller;


import com.dailycodebuffer.employeeservice.model.Employee;
import com.dailycodebuffer.employeeservice.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/employee")
@RequiredArgsConstructor
public class EmployeeController {

    private static final Logger LOGGER = Logger.getLogger(EmployeeController.class.getName());

    private final EmployeeRepository employeeRepository;

    @PostMapping
    public Employee addEmployee(@RequestBody Employee employee){
        LOGGER.info("Employee added");
        return employeeRepository.addEmployee(employee);
    }

    @GetMapping
    public List<Employee> getAllEmployees(){
        LOGGER.info("Getting all employees");
        return employeeRepository.getAllEmployees();
    }

    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable Long id){
        LOGGER.info("Getting employee by id: {}");
        return employeeRepository.getEmployeeById(id);
    }

    @GetMapping("/department/{departmentId}")
    public List<Employee> getEmployeesByDepartmentId(@PathVariable Long departmentId){
        LOGGER.info("Getting employees by department id: {}");
        return employeeRepository.getEmployeesByDepartmentId(departmentId);
    }


}
